plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "ai.mahfazti.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.mahfazti.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 260
        versionName = "2.6.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
