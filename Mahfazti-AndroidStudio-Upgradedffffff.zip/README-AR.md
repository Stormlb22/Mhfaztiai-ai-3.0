# Mahfazti.ai 2.6 — Android source + connected services

هذه حزمة مصدر Android Studio مع واجهة 2.6. احتفظ بنسخة JSON من التطبيق السابق قبل الانتقال؛ معرّف الحزمة والتوقيع قد يختلفان، لذلك لا تحذف النسخة القديمة قبل التأكد من الاستيراد.

## إضافات 2.6
- ملف Excel حقيقي بصيغة `.xlsx` (وليس CSV مع تسمية Excel).
- نسخ احتياطي مشفّر AES-256-GCM، بمفتاح مشتق عبر PBKDF2-SHA256 (250,000 دورة) وملح وIV عشوائيين. كلمة المرور لا تحفظها الواجهة.
- تخزين بيانات المحفظة محلياً في Android `EncryptedSharedPreferences` بدلاً من LocalStorage عند تشغيل نسخة Android الأصلية. متصفح HTML وحده يستخدم LocalStorage غير المشفّر؛ استخدم ملف `.mfbak` المشفّر هناك.
- واجهة منفصلة للسعر الرسمي وسعر السوق النقدي. يتطلب التحديث خادم Mahfazti `/api/rates`.
- مساعد AI يتصل بالخادم فقط عند تفعيله، ويرسل ملخصاً مالياً مجمعاً لا سجل الحركات الخام.
- نسخ سحابي تلقائي لكل جهاز عبر Firebase بعد تسجيل الدخول وتفعيل الخيار. تحفظ نسخة منفصلة لكل جهاز؛ اختيار الاستعادة يتم يدوياً لتجنب الكتابة فوق نسخة جهاز آخر بصمت.

## متطلبات البناء
- Android Studio حديث، JDK 17، Android SDK Platform 35.
- افتح مجلد المشروع في Android Studio ثم Gradle Sync وابنِ APK.
- لم يُبنَ APK هنا لأن بيئة العمل لا تحتوي Android SDK/Gradle build tools؛ لا تعتبر هذا المصدر APK مختبراً.

## Firebase
راجع `FIREBASE-SETUP.txt`. يتطلب مشروع Firebase تملكه، تفعيل Google Authentication وFirestore، وملف `google-services.json`. لا ترفع ملف الإعداد أو مفاتيحك إلى مستودع عام. انشر `firestore.rules` كما هي بعد مراجعتها.

## خادم الأسعار والذكاء الاصطناعي
راجع `backend/README-AR.md`. يتطلب استضافة HTTPS، عنواناً ثابتاً، ومفتاح API صالحاً محفوظاً على الخادم فقط. لا تضع `OPENAI_API_KEY` في APK أو HTML.

## Whish Money
لا يتضمن هذا الإصدار اتصالاً فعلياً بحساب Whish الشخصي. Whish Pay موصوف كبوابة دفع للتجار؛ نحتاج وثائق API رسمية وموافقة Whish وبيانات تاجر صالحة قبل بناء موصل حقيقي. لا تستخدم كلمة مرور تطبيق Whish ولا تعتمد على كشط البيانات.

## اختبارات محلية
```bash
node --check app/src/main/assets/index.js  # إذا استخرجت سكربت الواجهة إلى ملف JS
node tests/data-model.test.js
node tests/ui-artifacts.test.cjs
python -m pytest backend/tests -q
python tests/security_static.py
cd backend && pip install -r requirements.txt && pytest -q
```

## حدود الأمان والاختبار
- النسخ `.mfbak` مشفرة؛ إذا ضاعت كلمة المرور لا يمكن استعادتها.
- بيانات Android المحلية تستخدم EncryptedSharedPreferences، لكن هذا لا يغني عن قفل شاشة الهاتف وتحديث النظام.
- لا يوجد اختبار اختراق خارجي أو تدقيق أمني معتمد.
- الأسعار الموازية استرشادية وقد تتأخر؛ لا تستخدمها كعرض ملزم للبيع أو الشراء.
- Whish API والمساعد السحابي وأسعار الصرف لن تعمل قبل نشر الخادم وإعداد الحسابات المطلوبة.
