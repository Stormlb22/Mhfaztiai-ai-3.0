# خادم Mahfazti.ai 2.6

## ما يقدمه
- `/api/rates`: يجلب مرجع مصرف لبنان الرسمي منفصلاً عن متوسط السوق النقدي المنشور لدى Lira Rate. النتيجة مؤرخة وموسومة بالمصدر. متوسط السوق تقديري وليس عرض شراء/بيع ملزماً.
- `/api/ai`: يستخدم OpenAI Responses API من الخادم فقط. يستقبل سؤالاً وملخصاً رقمياً مجمعاً، ولا يستقبل سجل الحركات الخام أو الأوصاف أو المعرّفات.
- `/api/whish/status`: يعرض حالة انتظار التعاقد الرسمي فقط؛ لا يوجد endpoint مزيف للمدفوعات أو قراءة المحفظة.

## التشغيل
```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# عيّن OPENAI_API_KEY وOPENAI_MODEL على الخادم فقط، وحدد ALLOWED_ORIGINS
uvicorn server:app --host 0.0.0.0 --port 8000
```

استخدم HTTPS أمام الخادم. أضف بيانات خدمة Firebase Admin في `FIREBASE_SERVICE_ACCOUNT_JSON` (JSON كنص أو مسار ملف) للتحقق من Firebase ID tokens. لا تضع مفاتيح OpenAI أو Whish في APK أو HTML. فعّل مراقبة التكلفة وحدود الاستخدام ودوّر المفاتيح. لا تُسجّل أجسام طلبات AI في سجلات الخادم.

## أسعار الصرف
مصرف لبنان هو مرجع السعر الرسمي؛ يجلب الخادم أحدث ملاحظة منشورة في سلسلة كل عملة (USD/EUR/GBP/AED/SAR)، ويحتفظ بشهر نشر كل سلسلة. السعر النقدي يأتي من متوسط تجميعي عام لـ Lira Rate، وهو يصرّح أن بياناته قد لا تكون لحظية أو دقيقة دائماً؛ لذلك يعرضه التطبيق كمرجع استرشادي فقط ولا يخلطه بالسعر الرسمي. إذا تغيّر شكل صفحات المصادر، يرجع الخادم 503 ولا يضع سعراً افتراضياً.

## Whish Money
Whish Pay موصوفة رسمياً كبوابة دفع للتجار. لم تتوفر وثائق عامة كافية لقراءة معاملات محفظة فردية أو تنفيذ تحويلات شخصية من تطبيق خارجي. يلزم عقد/موافقة من Whish، وثائق API الرسمية، بيانات تاجر، ونقاط webhook. لا تستخدم كلمة مرور تطبيق Whish ولا تكشط بيانات التطبيق. حتى تسليم الوثائق الرسمية، التكامل غير مفعّل عمداً.

## حدود النشر
هذا خادم جاهز للتشغيل محلياً/على استضافة، لكنه لم يُنشر على الإنترنت بعد. تحتاج عنوان HTTPS ثابتاً، ومفتاح OpenAI صالحاً، وإعداد CORS. لا تعتبر الخدمات السحابية أو الذكاء الاصطناعي مباشراً قبل نشره واختبار اتصال التطبيق به.
## مصادر البيانات المستخدمة
- [مصرف لبنان — USD/LBP series](https://www.bdl.gov.lb/economicandfinancialdatasub.php?code=9&docId=161&filecode=90).
- [مصرف لبنان — EUR/LBP series](https://www.bdl.gov.lb/keyfiguressub.php?code=3&docId=158&filecode=321).
- [مصرف لبنان — GBP/LBP series](https://www.bdl.gov.lb/economicandfinancialdatasub.php?code=9&docId=147&filecode=90).
- [مصرف لبنان — AED/LBP series](https://www.bdl.gov.lb/keyfiguressub.php?code=3&docId=164&filecode=323).
- [مصرف لبنان — SAR/LBP series](https://www.bdl.gov.lb/keyfiguressub.php?code=3&docId=163&filecode=323).
- [Lira Rate — USD/LBP daily comparison](https://www.lira-rate.com/today/usd-lbp.php). الموقع يصرّح أن البيانات ليست بالضرورة لحظية أو دقيقة؛ لذلك يعرضها التطبيق كمتوسط استرشادي مع توقيت المصدر.

تاريخ آخر ملاحظة منشورة في سلاسل BDL قد يتأخر عن تاريخ اليوم (بعض الصفحات المعروضة حالياً تصل إلى Apr/2026). الخادم يعرض شهر المصدر كما هو ولا يختلق تحديثاً أحدث.
