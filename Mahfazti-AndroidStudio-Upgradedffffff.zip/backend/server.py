"""Mahfazti.ai secure API: exchange-rate proxy and privacy-minimized AI advisor.
Whish endpoints are intentionally not implemented until Whish supplies an approved API contract.
"""
from __future__ import annotations
import os, re, time, json, logging
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse
import httpx
try:
    import firebase_admin
    from firebase_admin import auth as firebase_auth, credentials
except ImportError:  # Allows rate parsing/tests without cloud extras installed.
    firebase_admin = None
    firebase_auth = None
    credentials = None
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("mahfazti")
app = FastAPI(title="Mahfazti.ai API", version="2.6.0")
_firebase_ready = False
_service_account = os.getenv("FIREBASE_SERVICE_ACCOUNT_JSON", "")
if _service_account and firebase_admin is not None:
    try:
        cred_data = json.loads(_service_account) if _service_account.lstrip().startswith("{") else credentials.Certificate(_service_account)
        cred = credentials.Certificate(cred_data) if isinstance(cred_data, dict) else cred_data
        if not firebase_admin._apps:
            firebase_admin.initialize_app(cred)
        _firebase_ready = True
    except Exception as exc:
        log.warning("Firebase Admin configuration invalid: %s", type(exc).__name__)
origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins or [], allow_credentials=False,
                   allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["Content-Type", "Authorization"])

_rate_cache: dict[str, Any] = {"at": 0.0, "payload": None}
_ai_hits: dict[str, list[float]] = {}


def _numbers(text: str) -> list[float]:
    return [float(x.replace(",", "")) for x in re.findall(r"(?<![\w.])\d{1,3}(?:,\d{3})+(?:\.\d+)?|(?<![\w.])\d+(?:\.\d+)?", text)]


def parse_bdl_rates(html: str) -> dict[str, float]:
    """Parse BDL's published current-rate table; fail closed if USD cannot be found."""
    soup = BeautifulSoup(html, "html.parser")
    result: dict[str, float] = {}
    for tr in soup.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
        if not cells:
            continue
        row = " ".join(cells).upper().replace(" ", "")
        for code in ("USD", "EUR", "GBP", "AED", "SAR", "CAD", "AUD", "CHF", "JPY"):
            if f"{code}/LBP" in row or f"{code}LBP" in row:
                vals = _numbers(" ".join(cells[1:]))
                if vals:
                    result[f"{code}_LBP"] = vals[-1]
    # Some BDL page variants use cards instead of table rows.
    if "USD_LBP" not in result:
        text = soup.get_text(" ", strip=True).upper()
        m = re.search(r"USD\s*/\s*LBP.{0,100}?([\d,]+(?:\.\d+)?)", text)
        if m:
            result["USD_LBP"] = float(m.group(1).replace(",", ""))
    if result.get("USD_LBP", 0) <= 0:
        raise ValueError("BDL USD/LBP rate not found; source layout may have changed")
    return result


def parse_latest_bdl_series(html: str) -> tuple[float, str]:
    """Return the latest published end-of-period (or mid) value and BDL month label."""
    soup = BeautifulSoup(html, "html.parser")
    month_re = re.compile(r"^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/\d{4}$", re.I)
    rows = []
    target_index = None
    for tr in soup.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
        if not cells:
            continue
        lower = [c.lower() for c in cells]
        for label in ("end of period", "mid"):
            if label in lower:
                target_index = lower.index(label)
                break
        if month_re.match(cells[0]):
            rows.append(cells)
    if not rows:
        raise ValueError("Latest BDL currency series row not found")
    cells = rows[0]
    if target_index is not None and target_index < len(cells):
        vals = _numbers(cells[target_index])
        if vals and vals[-1] > 0:
            return vals[-1], cells[0]
    vals = _numbers(" ".join(cells[1:]))
    if vals and vals[-1] > 0:
        return vals[-1], cells[0]
    raise ValueError("Latest BDL end-of-period value not found")


def parse_market_rate(html: str) -> tuple[float, str]:
    """Parse the aggregator's 5-source average, explicitly marked indicative."""
    text = BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
    patterns = [
        r"\$1\s*US\s*Dollars\s*in\s*Lebanon\s*in\s*average\s*is\s*([\d,]+(?:\.\d+)?)\s*LL",
        r"Average\s+Rate.{0,250}?([\d,]+(?:\.\d+)?)\s*(?:LL|LBP)",
    ]
    for pattern in patterns:
        m = re.search(pattern, text, re.I)
        if m:
            value = float(m.group(1).replace(",", ""))
            if value > 0:
                return value, "Lira Rate aggregator (5 public sources; indicative, not guaranteed real-time)"
    raise ValueError("Market average not found; do not substitute an assumed rate")


def parse_market_timestamp(html: str) -> str:
    text = BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
    m = re.search(r"Latest Update\s*:?[ ]*(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})", text, re.I)
    return m.group(1) if m else ""



async def _fetch_text(client: httpx.AsyncClient, url: str) -> str:
    r = await client.get(url, headers={"User-Agent": "MahfaztiAI/2.6 rate-reference"})
    r.raise_for_status()
    if len(r.content) > 3_000_000:
        raise ValueError("Upstream response too large")
    return r.text


@app.get("/api/health")
async def health():
    return {"ok": True, "version": "2.6.0", "ai_configured": bool(os.getenv("OPENAI_API_KEY")),
            "whish_status": "pending_official_api_contract"}


@app.get("/api/rates")
async def rates():
    now = time.time()
    if _rate_cache["payload"] and now - _rate_cache["at"] < 300:
        return _rate_cache["payload"]
    timeout = httpx.Timeout(12.0, connect=6.0)
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        try:
            series_urls = {
                "USD_LBP": "https://www.bdl.gov.lb/economicandfinancialdatasub.php?code=9&docId=161&filecode=90",
                "EUR_LBP": "https://www.bdl.gov.lb/economicandfinancialdatasub.php?code=9&docId=158&filecode=90",
                "GBP_LBP": "https://www.bdl.gov.lb/economicandfinancialdatasub.php?code=9&docId=147&filecode=90",
                "AED_LBP": "https://www.bdl.gov.lb/economicandfinancialdatasub.php?code=9&docId=164&filecode=90",
                "SAR_LBP": "https://www.bdl.gov.lb/economicandfinancialdatasub.php?code=9&docId=163&filecode=90",
            }
            import asyncio
            fetched = await asyncio.gather(*[_fetch_text(client, url) for url in series_urls.values()])
            market_html = await _fetch_text(client, "https://www.lira-rate.com/today/usd-lbp.php")
            official, official_series_dates = {}, {}
            for code, page in zip(series_urls.keys(), fetched):
                official[code], official_series_dates[code] = parse_latest_bdl_series(page)
            market_value, market_source = parse_market_rate(market_html)
            market_observed = parse_market_timestamp(market_html)
            official_observed = max(official_series_dates.values(), key=lambda x: (int(x.split('/')[1]), ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].index(x.split('/')[0])))
        except Exception as exc:
            log.warning("Rate provider unavailable: %s", type(exc).__name__)
            raise HTTPException(status_code=503, detail="Exchange-rate sources are temporarily unavailable; saved rates were not changed")
    payload = {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "official": {**official, "observed_at": official_observed, "series_dates": official_series_dates},
        "market": {"USD_LBP": market_value, "source": market_source, "observed_at": market_observed},
        "sources": {"official": "Banque du Liban current rates", "market": "Lira Rate five-source average"},
        "notice": "Market rate is an indicative cash-market reference and may differ from the quote offered by an exchange office.",
    }
    _rate_cache.update(at=now, payload=payload)
    return payload


class AISummary(BaseModel):
    month: str = Field(max_length=7)
    totals: dict[str, float] = Field(default_factory=dict)
    categories: list[dict[str, Any]] = Field(default_factory=list, max_length=40)
    goals: list[dict[str, Any]] = Field(default_factory=list, max_length=20)


class AIRequest(BaseModel):
    question: str = Field(min_length=1, max_length=1200)
    summary: AISummary


def _allow_ai(ip: str) -> bool:
    now = time.time()
    hits = [t for t in _ai_hits.get(ip, []) if now - t < 60]
    if len(hits) >= 12:
        _ai_hits[ip] = hits
        return False
    hits.append(now)
    _ai_hits[ip] = hits
    return True


@app.post("/api/ai")
async def ai(req: AIRequest, request: Request):
    if not _firebase_ready:
        raise HTTPException(status_code=503, detail="Firebase authentication is not configured on the server")
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Firebase sign-in is required")
    try:
        firebase_auth.verify_id_token(auth_header[7:].strip())
    except Exception:
        raise HTTPException(status_code=401, detail="Firebase session is invalid or expired")
    key = os.getenv("OPENAI_API_KEY", "")
    model = os.getenv("OPENAI_MODEL", "")
    if not key or not model:
        raise HTTPException(status_code=503, detail="AI service is not configured on the server")
    ip = request.client.host if request.client else "unknown"
    if not _allow_ai(ip):
        raise HTTPException(status_code=429, detail="Too many AI requests; try again shortly")
    # The app sends only month-level totals/category aggregates, never raw transaction descriptions or IDs.
    safe_summary = req.summary.model_dump()
    prompt = (
        "أنت المستشار المالي داخل تطبيق محفظتي. قدّم تحليلاً عملياً بالعربية، واضحاً وغير متعالٍ. "
        "لا تخترع أرقاماً ولا تقدّم نصيحة استثمارية أو ضريبية متخصصة. إذا كانت البيانات ناقصة فقل ذلك. "
        "لا تنفذ أي عملية مالية؛ اقترح فقط واترك القرار للمستخدم.\n\n"
        f"ملخص المستخدم المالي: {json.dumps(safe_summary, ensure_ascii=False)}\n"
        f"سؤال المستخدم: {req.question}"
    )
    timeout = httpx.Timeout(35.0, connect=8.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            response = await client.post("https://api.openai.com/v1/responses",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": model, "input": prompt, "max_output_tokens": 550})
            response.raise_for_status()
            body = response.json()
        except httpx.HTTPStatusError as exc:
            log.warning("AI provider returned status %s", exc.response.status_code)
            raise HTTPException(status_code=502, detail="AI provider rejected the request")
        except Exception as exc:
            log.warning("AI provider unavailable: %s", type(exc).__name__)
            raise HTTPException(status_code=502, detail="AI provider is temporarily unavailable")
    pieces = []
    for item in body.get("output", []):
        if item.get("type") == "message":
            for part in item.get("content", []):
                if part.get("type") == "output_text":
                    pieces.append(part.get("text", ""))
    answer = "\n".join(x for x in pieces if x).strip()
    if not answer:
        raise HTTPException(status_code=502, detail="AI response contained no text")
    return {"answer": answer, "model": model}


@app.get("/api/whish/status")
async def whish_status():
    # Whish Money's public site documents WhishPay as a merchant payment gateway,
    # but no public transaction-history API contract was located. Do not fake it.
    return {"connected": False, "status": "pending_official_api_contract",
            "message": "Requires Whish-issued API documentation, merchant approval and credentials. Personal-wallet transaction access is not assumed."}
