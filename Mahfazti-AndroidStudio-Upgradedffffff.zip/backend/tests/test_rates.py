import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import parse_bdl_rates, parse_market_rate

def test_parse_bdl_table():
    html='''<table><tr><td>USD/LBP</td><td>89,500.00</td><td>89,500.00</td><td>89,500.00</td></tr><tr><td>EUR/LBP</td><td>102,620.70</td></tr><tr><td>GBP/LBP</td><td>118,166.85</td></tr></table>'''
    out=parse_bdl_rates(html)
    assert out['USD_LBP']==89500.0 and out['EUR_LBP']==102620.7

def test_parse_market_average():
    html='<h3>Average Rate!</h3><p>$1 US Dollars in Lebanon in average is 89,600 LL</p>'
    value, source=parse_market_rate(html)
    assert value==89600 and '5 public sources' in source


def test_parse_latest_bdl_series():
    from server import parse_latest_bdl_series
    html='<table><tr><th>Period</th><th>Period Average</th><th>End of Period</th></tr><tr><td>Jul/2026</td><td>24368.27</td><td>24367.00</td></tr><tr><td>Jun/2026</td><td>24368.39</td><td>24369.66</td></tr></table>'
    assert parse_latest_bdl_series(html)==(24367.0,'Jul/2026')


def test_parse_bdl_end_of_period_first():
    from server import parse_latest_bdl_series
    html='<table><tr><th>Period</th><th>End of Period</th><th>Period Average</th></tr><tr><td>Jul/2026</td><td>120270.10</td><td>119733.88</td></tr></table>'
    assert parse_latest_bdl_series(html)==(120270.10,'Jul/2026')
