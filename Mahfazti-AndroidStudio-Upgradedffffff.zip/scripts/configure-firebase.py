#!/usr/bin/env python3
"""Extract this app's Firebase values from google-services.json without committing secrets."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_PACKAGE = "com.stormlb.mahfazti"
source = Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else ROOT / "google-services.json"
if not source.is_file():
    raise SystemExit(f"لم يتم العثور على الملف: {source}\nضع google-services.json بجانب settings.gradle.kts أو مرّر مساره.")

try:
    config = json.loads(source.read_text(encoding="utf-8"))
except Exception as exc:
    raise SystemExit(f"ملف JSON غير صالح: {exc}")

project_id = (config.get("project_info") or {}).get("project_id")
clients = config.get("client") or []
matched = []
for client in clients:
    info = client.get("client_info") or {}
    package_name = (info.get("android_client_info") or {}).get("package_name")
    if package_name == EXPECTED_PACKAGE:
        matched.append(client)
if not matched:
    raise SystemExit(f"هذا الملف لا يحتوي تطبيق Android بالمعرّف {EXPECTED_PACKAGE}.")

client = matched[0]
app_id = (client.get("client_info") or {}).get("mobilesdk_app_id")
api_keys = client.get("api_key") or []
api_key = api_keys[0].get("current_key") if api_keys else None
web_client_id = None
for item in client.get("oauth_client") or []:
    if item.get("client_type") == 3 and item.get("client_id"):
        web_client_id = item["client_id"]
        break

missing = [name for name, value in {
    "project_id": project_id,
    "mobilesdk_app_id": app_id,
    "api_key": api_key,
    "Web OAuth client ID": web_client_id,
}.items() if not value]
if missing:
    raise SystemExit("إعداد Firebase ناقص: " + ", ".join(missing) + ". فعّل Google ضمن Firebase Authentication ثم نزّل google-services.json مجدداً.")

values = {
    "FIREBASE_API_KEY": api_key,
    "FIREBASE_APP_ID": app_id,
    "FIREBASE_PROJECT_ID": project_id,
    "GOOGLE_WEB_CLIENT_ID": web_client_id,
}
out = ROOT / "firebase.local.properties"
out.write_text("# Generated locally from google-services.json; do not commit.\n" + "".join(f"{key}={value}\n" for key, value in values.items()), encoding="utf-8")
print(f"تم إعداد Firebase لهذا التطبيق. حُفظت القيم محلياً في: {out}")
print("لم يتم نسخ google-services.json إلى ملفات المشروع أو نشر أي بيانات.")
