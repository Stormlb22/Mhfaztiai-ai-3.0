// Lightweight regression tests for the embedded wallet data model.
// Run with: node tests/data-model.test.js
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(new URL('../app/src/main/assets/index.html', `file://${__filename}`), 'utf8');
let js = html.split('<script>')[1].split('</script>')[0];
// The final two calls render the UI and are intentionally excluded in this headless test.
js = js.replace(/processRecurring\(\);\s*render\(\);\s*$/, '');
const elements = new Map();
const document = {
  getElementById(id) {
    if (!elements.has(id)) elements.set(id, { textContent: '', value: '', classList: { add() {}, remove() {}, toggle() {} }, style: {}, innerHTML: '' });
    return elements.get(id);
  },
  querySelector() { return null; },
  createElement() { return { style: {}, focus() {}, select() {}, value: '' }; },
  body: { appendChild() {}, removeChild() {} },
  execCommand() { return true; }
};
const storage = new Map();
const context = {
  document,
  window: {},
  localStorage: { getItem: k => storage.get(k) ?? null, setItem: (k,v) => storage.set(k, String(v)) },
  setTimeout() {},
  scrollTo() {},
  Intl, Date, Math, JSON, Number, String, Array, Object, RegExp, Error,
  console
};
vm.createContext(context);
vm.runInContext(js, context, { timeout: 3000 });

const result = vm.runInContext(`normalizeData({
  fx: 90000,
  transactions: [{ id: 7, date: '2026-10-01', type: 'قبض', amount: '25', currency: 'USD' }, { amount: 'bad' }],
  goals: [{ name: 'هدف', target: '100', saved: '20' }],
  debts: [{ name: 'علي', amount: '40', kind: 'عليّ' }],
  recurring: [{ id: 'r1', description: 'فاتورة', amount: '10', day: 31, type: 'صرف', currency: 'LBP' }]
})`, context);
assert.equal(result.fx, 90000);
assert.equal(result.transactions.length, 2);
assert.equal(result.transactions[0].amount, 25);
assert.equal(result.transactions[1].amount, 0);
assert.equal(result.transactions[1].date.length, 10);
assert.equal(result.goals[0].saved, 20);
assert.equal(result.debts[0].kind, 'عليّ');
assert.equal(result.recurring[0].day, 28);

const parsed = vm.runInContext(`parseBackupText(JSON.stringify({
  transactions: [{ date: '2026-10-03', type: 'صرف', amount: 12, currency: 'USD' }],
  goals: [{ name: 'سفر', target: 500, saved: 50 }]
}))`, context);
assert.equal(parsed.transactions.length, 1);
assert.equal(parsed.goals[0].target, 500);
assert.throws(() => vm.runInContext(`parseBackupText('{"goals":[]}')`, context));
assert.throws(() => vm.runInContext(`parseBackupText('{"transactions":[{"amount":5}],"fx":0}')`, context));

// Goal contributions update the saved amount.
context.document.getElementById('goal-name').value = 'رحلة';
context.document.getElementById('goal-target').value = '300';
context.document.getElementById('goal-saved').value = '50';
vm.runInContext(`data=normalizeData({transactions:[],goals:[],debts:[],recurring:[]}); addGoal();`, context);
context.document.getElementById('goal-add-0').value = '25';
vm.runInContext(`contributeGoal(0);`, context);
assert.equal(vm.runInContext(`data.goals[0].saved`, context), 75);

// Partial debt payments are capped at the original debt amount.
context.document.getElementById('debt-name').value = 'مورد';
context.document.getElementById('debt-amount').value = '100';
context.document.getElementById('debt-kind').value = 'عليّ';
context.document.getElementById('debt-note').value = '';
vm.runInContext(`addDebt();`, context);
context.document.getElementById('debt-pay-0').value = '120';
vm.runInContext(`payDebt(0);`, context);
assert.equal(vm.runInContext(`data.debts[0].paid`, context), 100);

// Recurring movements are not duplicated within the same month.
vm.runInContext(`data=normalizeData({transactions:[],recurring:[{id:'test-rec',description:'اشتراك',amount:9,day:1,type:'صرف',currency:'USD'}]}); processRecurring(); processRecurring();`, context);
assert.equal(vm.runInContext(`data.transactions.length`, context), 1);

console.log('Mahfazti data-model tests: PASS');
