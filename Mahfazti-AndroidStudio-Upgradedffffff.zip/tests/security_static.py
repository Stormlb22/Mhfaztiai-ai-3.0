from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
html = (ROOT/'app/src/main/assets/index.html').read_text(encoding='utf-8')
kotlin = (ROOT/'app/src/main/java/com/stormlb/mahfazti/MainActivity.kt').read_text(encoding='utf-8')
manifest = (ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
rules = (ROOT/'firestore.rules').read_text(encoding='utf-8')
backend = (ROOT/'backend/server.py').read_text(encoding='utf-8')
assert 'AES-GCM' in html and 'iterations:250000' in html
assert 'EncryptedSharedPreferences' in kotlin and 'saveWallet' in kotlin and 'loadWallet' in kotlin
assert 'WebViewAssetLoader' in kotlin and 'allowFileAccess = false' in kotlin
assert 'android:allowBackup="false"' in manifest and 'android:usesCleartextTraffic="false"' in manifest
assert 'android.permission.INTERNET' in manifest
assert 'request.auth.uid == userId' in rules
assert 'firebase_auth.verify_id_token' in backend
assert 'OPENAI_API_KEY' in backend and 'Authorization' in backend
assert 'eval(' not in html and 'new Function(' not in html
# There must be no real API secret embedded in client-side sources.
for path in [ROOT/'app/src/main/assets/index.html', ROOT/'app/src/main/java/com/stormlb/mahfazti/MainActivity.kt']:
    body = path.read_text(encoding='utf-8')
    assert not re.search(r'sk-[A-Za-z0-9]{20,}', body)
print('Static security checks passed (not a penetration test).')
