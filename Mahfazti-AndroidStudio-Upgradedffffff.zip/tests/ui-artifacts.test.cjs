const fs = require('fs');
const vm = require('vm');
const { webcrypto } = require('crypto');
const source = fs.readFileSync(require('path').join(__dirname, 'ui-script.js'), 'utf8');

async function testXlsx() {
  const exp = source.slice(source.indexOf('function exportExcel(){'), source.indexOf('function exportPDF(){'));
  let saved;
  const ctx = {
    data: { transactions: [{ date:'2026-11-01', type:'قبض', description:'راتب', category:'عمل', amount:500, currency:'USD', walletId:'w1' }], wallets:[{id:'w1',name:'الدولار'}], fx:89500 },
    usd: t => t.amount, today: () => '2026-11-01', downloadFile: (_n, blob) => { saved = blob; }, toast: () => {},
    Blob, TextEncoder, Uint8Array, URL
  };
  vm.createContext(ctx); vm.runInContext(exp, ctx); ctx.exportExcel();
  const bytes = new Uint8Array(await saved.arrayBuffer());
  if (bytes[0] !== 0x50 || bytes[1] !== 0x4b) throw new Error('XLSX ZIP signature missing');
  const decoded = new TextDecoder().decode(bytes);
  if (!decoded.includes('xl/workbook.xml') || !decoded.includes('راتب')) throw new Error('XLSX workbook content missing');
}

async function testEncryptedBackup() {
  const a = source.indexOf('function b64u('), b = source.indexOf('function aiSummaryForPrivacy()');
  const code = source.slice(a, b);
  let downloaded = '', restored = ''; const messages = []
  const pass = { value: 'correct-horse-battery-2026' };
  const ctx = {
    crypto: webcrypto, TextEncoder, TextDecoder, Uint8Array, Blob, btoa, atob,
    document: { getElementById: id => id === 'backup-passphrase' ? pass : null },
    backupStr: () => JSON.stringify({ transactions: [{ id:'tx1', amount:42 }] }),
    today: () => '2026-11-01', downloadFile: (_name, content) => { downloaded = content; }, toast: message => messages.push(message),
    applyBackupText: raw => { restored = raw; return true; }
  };
  vm.createContext(ctx); vm.runInContext(code, ctx);
  await vm.runInContext('exportEncryptedBackup()', ctx);
  const payload = JSON.parse(downloaded);
  if (payload.cipher !== 'AES-256-GCM' || payload.iterations !== 250000) throw new Error('Encryption parameters missing');
  ctx.ev = { target: { files: [{ size: downloaded.length, text: async () => downloaded }], value: '' } };
  await vm.runInContext('importEncryptedBackup(ev)', ctx);
  if (!restored.includes('"amount":42')) throw new Error('Encrypted backup roundtrip failed');
  if (!messages.some(m => m.includes('راجع النسخة ثم أكّد الاستعادة'))) throw new Error('Restore confirmation feedback missing');
}

(async () => { await testXlsx(); await testEncryptedBackup(); console.log('UI artifact tests passed: XLSX ZIP + AES-GCM backup roundtrip'); })().catch(e => { console.error(e); process.exit(1); });
