package com.stormlb.mahfazti

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.webkit.*
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.webkit.WebViewAssetLoader
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingExportBytes: ByteArray? = null
    private var pageReady = false
    private var auth: FirebaseAuth? = null
    private var store: FirebaseFirestore? = null
    private val prefs by lazy {
        val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(this, "mahfazti_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    private val deviceId: String by lazy { prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("device_id", it).apply() } }
    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        fileCallback = null
    }
    private val saveFileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        val bytes = pendingExportBytes
        if (result.resultCode == Activity.RESULT_OK && uri != null && bytes != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                status("تم حفظ الملف بنجاح")
            } catch (_: Exception) { status("تعذر حفظ الملف في الموقع المحدد") }
        } else status("تم إلغاء حفظ الملف")
        pendingExportBytes = null
    }
    private val googleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            try {
                val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).getResult(ApiException::class.java)
                val credential = GoogleAuthProvider.getCredential(account.idToken, null)
                auth?.signInWithCredential(credential)?.addOnSuccessListener {
                    status("تم تسجيل الدخول: ${it.user?.email ?: "Google"}")
                }?.addOnFailureListener { status("فشل تسجيل الدخول: ${it.localizedMessage}") }
            } catch (e: Exception) { status("تعذر تسجيل الدخول بحساب Google") }
        } else status("تم إلغاء تسجيل الدخول")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initFirebaseIfConfigured()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        web = WebView(this)
        setContentView(web)
        ViewCompat.setOnApplyWindowInsetsListener(web) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) web.settings.safeBrowsingEnabled = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.addJavascriptInterface(Bridge(), "AndroidMahfazti")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                filePicker.launch("*/*")
                return true
            }
            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult?): Boolean {
                val input = EditText(this@MainActivity).apply { setText(defaultValue ?: ""); setSingleLine(true) }
                AlertDialog.Builder(this@MainActivity).setTitle("محفظتي")
                    .setMessage(message ?: "").setView(input)
                    .setPositiveButton("متابعة") { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }.show()
                return true
            }
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setTitle("تأكيد")
                    .setMessage(message ?: "")
                    .setPositiveButton("نعم") { _, _ -> result?.confirm() }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }.show()
                return true
            }
        }
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): android.webkit.WebResourceResponse? {
                return request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                // Only the bundled app page receives the native bridge. External links open outside WebView.
                if (uri.host == "appassets.androidplatform.net") return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (_: Exception) { true }
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                if (isPinEnabled()) web.evaluateJavascript("document.getElementById('pin-lock')?.classList.add('show')", null)
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun initFirebaseIfConfigured() {
        val api = BuildConfig.FIREBASE_API_KEY
        val appId = BuildConfig.FIREBASE_APP_ID
        val project = BuildConfig.FIREBASE_PROJECT_ID
        if (listOf(api, appId, project, BuildConfig.GOOGLE_WEB_CLIENT_ID).any { it == "SET_ME" }) return
        val options = FirebaseOptions.Builder().setApiKey(api).setApplicationId(appId).setProjectId(project).build()
        if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this, options)
        auth = FirebaseAuth.getInstance()
        store = FirebaseFirestore.getInstance()
    }

    private fun status(message: String) {
        runOnUiThread { web.evaluateJavascript("onGoogleStatus(${JSONObject.quote(message)})", null) }
    }

    private fun pinHash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
    private fun isPinEnabled() = prefs.contains("pin_hash") && prefs.contains("pin_salt")
    private fun showLock() { web.evaluateJavascript("document.getElementById('pin-lock')?.classList.add('show')", null) }

    inner class Bridge {
        // Financial state is stored inside EncryptedSharedPreferences (AES-256-GCM at rest).
        @JavascriptInterface fun loadWallet(): String = try { prefs.getString("wallet_data", "") ?: "" } catch (_: Exception) { "" }

        @JavascriptInterface fun saveWallet(json: String): Boolean = try {
            if (json.toByteArray(Charsets.UTF_8).size > 700_000) false
            else { JSONObject(json); prefs.edit().putString("wallet_data", json).commit() }
        } catch (_: Exception) { false }

        @JavascriptInterface fun saveFile(name: String, mime: String, base64: String): Boolean {
            return try {
            if (base64.length > 14_000_000 || name.length > 160) return false
            val safeName = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            if (bytes.size > 10_000_000) return false
            pendingExportBytes = bytes
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = mime.ifBlank { "application/octet-stream" }
                putExtra(Intent.EXTRA_TITLE, safeName)
            }
            runOnUiThread { saveFileLauncher.launch(intent) }
            true
        } catch (_: Exception) { false }
        }

        @JavascriptInterface fun setPin(pin: String): Boolean = try {
            if (!pin.matches(Regex("\\d{4,8}"))) false else {
                val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                prefs.edit().putString("pin_salt", android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP))
                    .putString("pin_hash", android.util.Base64.encodeToString(pinHash(pin, salt), android.util.Base64.NO_WRAP))
                    .remove("pin_failures").remove("pin_locked_until").apply()
                true
            }
        } catch (_: Exception) { false }

        @JavascriptInterface fun verifyPin(pin: String): Boolean {
            return try {
                val now = System.currentTimeMillis()
                if (now < prefs.getLong("pin_locked_until", 0L)) {
                    false
                } else {
                    val salt = android.util.Base64.decode(prefs.getString("pin_salt", "") ?: "", android.util.Base64.NO_WRAP)
                    val expected = android.util.Base64.decode(prefs.getString("pin_hash", "") ?: "", android.util.Base64.NO_WRAP)
                    val valid = MessageDigest.isEqual(expected, pinHash(pin, salt))
                    if (valid) {
                        prefs.edit().remove("pin_failures").remove("pin_locked_until").apply()
                        runOnUiThread { web.evaluateJavascript("document.getElementById('pin-lock')?.classList.remove('show')", null) }
                    } else {
                        val failures = prefs.getInt("pin_failures", 0) + 1
                        val edit = prefs.edit().putInt("pin_failures", failures)
                        if (failures >= 5) edit.putLong("pin_locked_until", now + 30_000L).putInt("pin_failures", 0)
                        edit.apply()
                    }
                    valid
                }
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun isPinEnabled() = this@MainActivity.isPinEnabled()
        @JavascriptInterface fun disablePin() { prefs.edit().remove("pin_salt").remove("pin_hash").apply() }

        @JavascriptInterface fun authenticateBiometric() {
            runOnUiThread {
                val prompt = BiometricPrompt(this@MainActivity, ContextCompat.getMainExecutor(this@MainActivity),
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            web.evaluateJavascript("document.getElementById('pin-lock')?.classList.remove('show')", null)
                            status("تم فتح المحفظة بالبصمة")
                        }
                        override fun onAuthenticationError(code: Int, err: CharSequence) { status("تعذر استخدام البصمة: $err") }
                    })
                val manager = BiometricManager.from(this@MainActivity)
                val capability = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                if (capability != BiometricManager.BIOMETRIC_SUCCESS) {
                    status(when (capability) {
                        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "ما في بصمة مسجلة على الهاتف. سجّل بصمة من إعدادات الجهاز أولاً"
                        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "هذا الهاتف لا يدعم مستشعر بصمة متوافقاً"
                        BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "مستشعر البصمة غير متاح حالياً"
                        else -> "البصمة غير جاهزة على هذا الجهاز"
                    })
                    return@runOnUiThread
                }
                val info = BiometricPrompt.PromptInfo.Builder().setTitle("فتح محفظتي")
                    .setSubtitle("أكد هويتك للوصول إلى المحفظة").setNegativeButtonText("إلغاء").build()
                prompt.authenticate(info)
            }
        }

        @JavascriptInterface fun googleAccount(): String = auth?.currentUser?.email ?: ""

        @JavascriptInterface fun requestFirebaseToken() {
            val user = auth?.currentUser
            if (user == null) { web.evaluateJavascript("onFirebaseToken('')", null); return }
            user.getIdToken(false).addOnSuccessListener { result ->
                web.evaluateJavascript("onFirebaseToken(${JSONObject.quote(result.token ?: "")})", null)
            }.addOnFailureListener { web.evaluateJavascript("onFirebaseToken('')", null) }
        }

        @JavascriptInterface fun googleSignOut() {
            runOnUiThread {
                auth?.signOut()
                status("تم تسجيل الخروج من حساب Google")
            }
        }

        @JavascriptInterface fun googleSignIn() {
            runOnUiThread {
                if (auth == null) { status("أكمل إعداد Firebase وGoogle OAuth أولاً"); return@runOnUiThread }
                val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail().requestIdToken(BuildConfig.GOOGLE_WEB_CLIENT_ID).build()
                googleLauncher.launch(GoogleSignIn.getClient(this@MainActivity, options).signInIntent)
            }
        }

        @JavascriptInterface fun cloudSave(json: String) {
            val user = auth?.currentUser
            if (user == null || store == null) { status("فعّل تسجيل الدخول بحساب Google أولاً"); return }
            if (json.toByteArray(Charsets.UTF_8).size > 700_000) { status("النسخة كبيرة جداً للحفظ السحابي؛ استخدم نسخة مشفّرة محلية"); return }
            val payload = mapOf("backupJson" to json, "updatedAt" to System.currentTimeMillis(),
                "schemaVersion" to 3, "deviceId" to deviceId, "deviceName" to (Build.MODEL ?: "Android"))
            store!!.collection("wallets").document(user.uid).collection("devices").document(deviceId).set(payload)
                .addOnSuccessListener { status("تم تحديث نسخة هذا الجهاز على السحابة؛ نسخ الأجهزة الأخرى محفوظة") }
                .addOnFailureListener { status("تعذر تحديث النسخة السحابية: ${it.localizedMessage}") }
        }

        @JavascriptInterface fun cloudLoad() {
            val user = auth?.currentUser
            if (user == null || store == null) { status("سجّل الدخول بحساب Google أولاً"); return }
            store!!.collection("wallets").document(user.uid).collection("devices").get()
                .addOnSuccessListener { snapshot ->
                    val list = org.json.JSONArray()
                    for (doc in snapshot.documents) {
                        val payload = doc.getString("backupJson") ?: continue
                        val item = JSONObject().put("deviceId", doc.id)
                            .put("deviceName", doc.getString("deviceName") ?: "Android")
                            .put("updatedAt", doc.getLong("updatedAt") ?: 0L)
                            .put("backupJson", payload)
                        list.put(item)
                    }
                    web.evaluateJavascript("onCloudSnapshots(${JSONObject.quote(list.toString())})", null)
                }.addOnFailureListener { status("فشل تحميل قائمة النسخ السحابية: ${it.localizedMessage}") }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized && pageReady && isPinEnabled()) showLock()
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
