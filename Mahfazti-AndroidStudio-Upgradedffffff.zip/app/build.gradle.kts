import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val firebaseLocalProperties = Properties().apply {
    val configFile = rootProject.file("firebase.local.properties")
    if (configFile.exists()) {
        configFile.inputStream().use { stream ->
            load(stream)
        }
    }
}
fun firebaseValue(name: String): String = (project.findProperty(name)?.toString()
    ?: firebaseLocalProperties.getProperty(name) ?: "SET_ME")
    .replace("\\", "\\\\").replace("\"", "\\\"")

android {
    namespace = "com.stormlb.mahfazti"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.stormlb.mahfazti"
        minSdk = 23
        targetSdk = 35
        versionCode = 26
        versionName = "2.6.0"
        buildConfigField("String", "FIREBASE_API_KEY", "\"${firebaseValue("FIREBASE_API_KEY")}\"")
        buildConfigField("String", "FIREBASE_APP_ID", "\"${firebaseValue("FIREBASE_APP_ID")}\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\"${firebaseValue("FIREBASE_PROJECT_ID")}\"")
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"${firebaseValue("GOOGLE_WEB_CLIENT_ID")}\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.biometric:biometric:1.2.0-alpha05")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
}
