@echo off
set VERSION=8.9
set ROOT=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VERSION%-bin\manual
set GRADLE=%ROOT%\gradle-%VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  if not exist "%ROOT%" mkdir "%ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ROOT%\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%ROOT%\gradle-%VERSION%-bin.zip' '%ROOT%'"
)
call "%GRADLE%" %*
